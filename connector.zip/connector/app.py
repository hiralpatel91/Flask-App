from flask import Flask, Response,render_template,request,redirect,flash,session
from flask_sqlalchemy import SQLAlchemy
import psycopg2 #pip install psycopg2 
import psycopg2.extras
import xlwt
import io
import re
from werkzeug.security import generate_password_hash, check_password_hash



app = Flask(__name__)

# app.config["SQLALCHEMY_DATABASE_URI"] = 'postgresql://postgres:root@localhost/sampledb'
app.secret_key = 'd632a7b2cfcb'
# db = SQLAlc   hemy(app)
# app.app_context().push()

# class Student(db.Model):
#     __tablename__='students'
#     id = db.Column(db.Integer,primary_key=True)
#     fname=db.Column(db.String(40))
#     lname=db.Column(db.String(40))
#     email=db.Column(db.String(40))
    
#     def __init__(self,fname,lname,email):
#         self.fname=fname
#         self.lname = lname
#         self.email=email
        
# db.create_all()


DB_HOST = "localhost"
DB_NAME = "sampledb"
DB_USER = "postgres"
DB_PASS = "root"
conn = psycopg2.connect(dbname=DB_NAME, user=DB_USER, password=DB_PASS, host=DB_HOST)

@app.route('/')
def index():
    cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
    s = "SELECT * FROM students"
    cur.execute(s) # Execute the SQL
    list_users = cur.fetchall()
    return render_template('index.html',list_users=list_users)

@app.route('/add_student',methods=['POST'])
def add_student():
    cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
    if request.method == 'POST':
        fname = request.form['fname']
        lname = request.form['lname']
        email = request.form['email']
        cur.execute("INSERT INTO students (fname, lname, email) VALUES (%s,%s,%s)",(fname,lname,email))
        conn.commit()
        flash('Student added successfully','success')
        return redirect('/')

@app.route('/edit/<id>',methods=['POST','GET'])
def get_employee(id):
    cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
    cur.execute('SELECT * FROM students WHERE id = %s', (id))
    data = cur.fetchall()
    cur.close()
    print(data[0])
    return render_template('edit.html',student=data[0])


@app.route('/update/<id>',methods=['POST'])
def update_students(id):
    if request.method == 'POST':
        fname = request.form['fname']
        lname = request.form['lname']
        email = request.form['email']
        
        cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
        cur.execute("""
                    UPDATE students
                    SET fname = %s,
                        lname = %s,
                        email = %s
                    WHERE ID = %s
                """,(fname, lname, email, id))
        flash('Student Updated Successfully','success')
        conn.commit()
        return redirect('/')

@app.route('/delete/<string:id>',methods=['POST','GET'])
def delete_student(id):
    cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
    cur.execute('DELETE FROM students WHERE id = {0}'.format(id))
    conn.commit()
    flash('Student Removed Successfully','danger')
    return redirect('/')

@app.route('/download/report/excel')
def download_report():
    cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
    cur.execute("SELECT * FROM students")
    result = cur.fetchall()
    
    # output in bytes
    output = io.BytesIO()
    # create workbook object
    workbook = xlwt.Workbook()
    # add a sheet
    sh = workbook.add_sheet('Student Report')
    # add headers
    sh.write(0, 0, 'Id')
    sh.write(0, 1, 'Fname')
    sh.write(0, 2, 'Lname')
    sh.write(0, 3, 'Email')
    
    idx = 0
    for row in result:
        sh.write(idx+1, 0, str(row['id']))
        sh.write(idx+1, 1, row['fname'])
        sh.write(idx+1, 2, row['lname'])
        sh.write(idx+1, 3, row['email'])
        idx+=1
        
    workbook.save(output)
    output.seek(0)
    return Response(output,mimetype="application/ms-excel",headers={"Content-Disposition":"attachment;filename=student_report.xls"})
    
    
    
# register
@app.route('/register',methods=['GET','POST'])
def register():
    cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
    if request.method == 'POST' and 'username' in request.form and 'password' in request.form and 'email' in request.form:
        fullname = request.form['fullname']
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        
        _hashed_password = generate_password_hash(password)
        cur.execute('SELECT * FROM users WHERE username = %s', (username,))
        account = cur.fetchone()
        print(account)
        
        # validations
        if account:
            flash('Account already exists!')
        elif not re.match(r'[^@]+@[^@]+\.[^@]+', email):
            flash('Invalid Email Address!')
        elif not re.match(r'[A-Za-z0-9]+',username):
            flash('Username Must contain only characters and numbers!')
        elif not username or not password or not email:
            flash('Please fill out the form')
        else:
            cur.execute("INSERT INTO users (fullname, username, password, email) VALUES (%s,%s,%s,%s)", (fullname, username, _hashed_password, email))
            conn.commit()
            flash('You Have Successfully Registered')
    return render_template('register.html')
    
    
@app.route('/login/',methods=['GET','POST'])
def login():
    cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
    
    if request.method == 'POST' and 'username' in request.form and 'password' in request.form:
        username = request.form['username']
        password = request.form['password']
        print(password)
        
        cur.execute('SELECT * FROM users WHERE username = %s', (username,))
        account = cur.fetchone()
        if account:
            password_rs = account['password']
            print(password_rs)
            if check_password_hash(password_rs,password):
                # create the session data ,we can access this data in other routes
                session['loggedin'] = True
                session['id'] = account['id']
                session['username'] = account['username']
                return redirect('/')
            else:
                flash('Incorrect username/password')
        else:
            flash('Incorrect username/password')
    return render_template('login.html')
    
if __name__ == "__main__":
    app.run(debug=True)